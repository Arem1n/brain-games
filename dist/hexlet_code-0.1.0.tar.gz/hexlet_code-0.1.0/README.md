### Hexlet tests and linter status:
[![Actions Status](https://github.com/Arem1n/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Arem1n/python-project-49/actions)
<a href="https://codeclimate.com/github/Arem1n/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/65c74dfe6023f3755d1e/maintainability" /></a>
